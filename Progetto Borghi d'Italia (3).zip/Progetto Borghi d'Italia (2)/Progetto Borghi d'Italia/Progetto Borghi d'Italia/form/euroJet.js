const areoporti = [
    { value: "VNO", text: "Aeroporto di Verona Villafranca" },
    { value: "GOA", text: "Aeroporto di Genova Cristoforo Colombo" },
    { value: "OLB", text: "Aeroporto di Olbia Costa Smeralda" },
    { value: "FLR", text: "Aeroporto di Firenze Amerigo Vespucci" },
    { value: "SUF", text: "Aeroporto di Lamezia Terme" },
    { value: "PMI", text: "Aeroporto di Palma di Maiorca (Spagna)" },
    { value: "TRS", text: "Aeroporto di Trieste Friuli Venezia Giulia" },
    { value: "PSA", text: "Aeroporto di Pisa Galileo Galilei" },
    { value: "BDS", text: "Aeroporto di Brindisi Salento" },
    { value: "REG", text: "Aeroporto di Reggio Calabria Tito Minniti" },
    { value: "CMF", text: "Aeroporto di Chambery (Francia)" },
    { value: "ZRH", text: "Aeroporto di Zurigo (Svizzera)" },
    { value: "AMS", text: "Aeroporto di Amsterdam Schiphol (Paesi Bassi)" },
    { value: "CDG", text: "Aeroporto di Parigi Charles de Gaulle (Francia)" },
    { value: "LHR", text: "Aeroporto di Londra Heathrow (Regno Unito)" },
    { value: "FRA", text: "Aeroporto di Francoforte (Germania)" },
    { value: "MUC", text: "Aeroporto di Monaco di Baviera (Germania)" },
    { value: "JFK", text: "Aeroporto John F. Kennedy di New York (USA)" },
    { value: "LAX", text: "Aeroporto di Los Angeles (USA)" },
    { value: "DXB", text: "Aeroporto di Dubai International (Emirati Arabi Uniti)" }
];


//Rilevo il modulo di prenotazione
const prenotazioneForm = document.getElementById('prenotazioneForm');

//Rilevo gli input e le select del modulo




//rilevo il div nascosto con opzioni per il ritorno
const divRitorno = document.getElementById('dataEOraRitorno')

//rileva il div del preventivo
const divPreventivo = document.getElementById('preventivo')

//rilevo lo span dove va messo il nome e il cognome
const spanNome = document.getElementById('outputNomeCognome')

//rilevo lo span per il prezzo
const spanPrezzo = document.getElementById('prezzoBiglietto')




//inietto l'option list degli aeroporti con il metodo createElement()
document.addEventListener('DOMContentLoaded', function() {
for (let i = 0; i < areoporti.length; i++) {


   
}})
//idem per la destinazione



// Gestisco la visualizzazione dinamica dell'input di ritorno con l'evento "change" sulla checkbox
   


// Gestisco la visualizzazione del preventivo quando il modulo viene inviato (evento "submit")
prenotazioneForm.addEventListener('submit', function(e) {

    // 1. Evito l'invio del modulo (devo avere i dati disponibili e il refresh della pagina me li farebbe perdere)
    
    // 2. Calcolo il prezzo del biglietto in base ai dati inseriti dall'utente

    // 3. inizio a caricare i dati nel div del preventivo

    // 3.1 inizio dal nome e cognome

    // 3.2 passo al contenuto del paragrafo: mi preparo due stringhe diverse a seconda che l'utente abbia selezionato andata e ritorno o meno

    // 3.3 inserisco il prezzo del biglietto

    // 4. Visualizzo il div del preventivo
    
});
