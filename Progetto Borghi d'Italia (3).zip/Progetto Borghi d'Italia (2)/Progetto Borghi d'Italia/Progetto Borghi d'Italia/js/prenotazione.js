const hotel = [
    { value: "331", text: "Wellness Hotel Casa Barca" },
    { value: "425", text: "The view house" },
    { value: "640", text: "Casella's apartment" },
    { value: "171", text: "Hotel Firenze" },
    { value: "181", text: "Hotel Sole Malcesine" },
    { value: "178", text: "Hotel Campagnola" },
    { value: "218", text: "Casa Ines" },
]


const prenotazioneForm = document.getElementById('prenotazioneForm')

// Rileva gli input del modulo
const inputList = document.querySelectorAll('input')
const selectList = document.querySelectorAll('select')

const nome = inputList[0]
const cognome = inputList[1]
const hotelPreso = selectList[0]
const nNotti = inputList[2]
const dataPartenza = inputList[3]



//rilevo il div del preventivo
const divPreventivo = document.getElementById('preventivo')

//rilevo lo span dove va messo il nome e il cognome
const spanNome = document.getElementById('outputNomeCognome')

//rilevo lo span per il prezzo
const spanPrezzo = document.getElementById('prezzoPreventivo')

// Gestisco la presentazione del preventivo quando il modulo viene inviato (evento "submit")
document.addEventListener('DOMContentLoaded', function() {
    for (let i = 0; i < hotel.length; i++) { //per ogni aeroporto
        const option = document.createElement('option'); //passo 1: creo l'elemento
        option.value = hotel[i].value  //passo 2: personalizzo l'elemento
        option.textContent = hotel[i].text
        hotelPreso.appendChild(option) //passo 3: inserisco l'elemento nel documento
    }})

prenotazioneForm.addEventListener('submit', function(event) {
    event.preventDefault(); // Evita l'invio del modulo, altrimenti la pagina si ricarica e i dati vengono persi
    
    let nomeHotel = "cio"
    let prezzo = hotelPreso.value*nNotti.value
    for (let i = 0; i < hotel.length; i++){
        if(hotel[i].value==prezzo){
            nomeHotel=hotel[i].text
            break
        }

    }    

    console.log(nomeHotel)
    //inietto i dati nel div del preventivo, iniziamo con il nome e cognome
    spanNome.innerHTML ="<strong>" +nome.value + ' ' + cognome.value+"</strong>"
    
    
    //il paragrafo sottostante dipende dalla selezione di andata e ritorno
    
    const paragrafo = document.getElementById('contenuto')//rilevo il paragrafo per il contenuto del preventivo
    let str //stringa che contiene il contenuto del paragrafo
    
    //se non è selezionato il ritorno
    
    str=    'Ecco un preventivo per la sua vacanza al '+ nomeHotel +
            '</strong> dal giorno <strong>' + 
            dataPartenza.value + '</strong> per '+ nNotti.value+' notti.' 
    
    
    
    console.log(str)
    console.log(hotel[0].value)
    console.log(hotelPreso.value)
    divPreventivo.style.display='block' //mostro il div del preventivo
    paragrafo.innerHTML=str   //inietto la stringa nel paragrafo
    spanPrezzo.innerHTML = String(prezzo) //mostro il prezzo
    
})
    